#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <fcntl.h>
#include <mpi.h>

int main() {
	
	/*
	char line[256];
	
	FILE *fileWords, *fileShadow;

	if ((fileWords = fopen("words.txt", "r")) == NULL) {
		fprintf(stderr, "No words.txt\n");
		return 1;
	}

	fseek(fileWords, 15, SEEK_SET);
	fgets(line, 256, fileWords);

	printf("%s\n", line);

	fclose(fileWords);
	*/
	
	MPI_Init(NULL, NULL);

	MPI_Comm world = MPI_COMM_WORLD;
	int rank, worldSize;
	MPI_Comm_size(world, &worldSize);
	MPI_Comm_rank(world, &rank);

	MPI_File fh;

	const char *fname = "outfile.data";

	MPI_File_open(
		world,
		fname,
		MPI_MODE_CREATE | MPI_MODE_RDWR,
		MPI_INFO_NULL,
		&fh
	);

	int offset = (rank+1)*50*sizeof(char);

	char t[50];
	memset(t, ' ', 50);
	t[49] = '\n';

	sprintf(t, "testing");

	if (rank == 0) {
	MPI_File_write_at(fh,
		offset,
		t,
		50,
		MPI_CHAR,
		MPI_STATUS_IGNORE);
	}


	char v[50];
	memset(v, ' ', 50);
	v[49] = '\n';
	sprintf(v, "again");
	if (rank == 1) {
	MPI_File_write_at(fh,
		offset,
		v,
		50,
		MPI_CHAR,
		MPI_STATUS_IGNORE);
	}

	offset = (0)*50*sizeof(char);
	memset(v, ' ', 50);
	v[49] = '\n';
	sprintf(v, "hi");

	if (rank == 2) {
	MPI_File_write_at(fh,
		offset,
		v,
		50,
		MPI_CHAR,
		MPI_STATUS_IGNORE);
	}


	MPI_File_close(&fh);

	MPI_Finalize();
	return 0;
}
