#include<stdio.h>
#include<stdlib.h>
#include<mpi.h>
#include<unistd.h>
#include<time.h>

int main(int argc, char** argv){
  MPI_Init(NULL,NULL);

  MPI_Comm world = MPI_COMM_WORLD;
  int worldSize, rank;
  MPI_Comm_size(world, &worldSize);
  MPI_Comm_rank(world, &rank);

  /*
   * All non-roots will async wait for messages from root, then start
   * doing some things.
   *
   * The root will prentend to work for a while (i.e. sleep) and then
   * start sending messages to each other node.
   */

  int numTasks = 3;
  int tasksDone[] = {0,0,0};
  int allDone = 0;
  MPI_Request rqsts[6];

  if( rank == 0 ){
    sleep(2);
    int one = 1;
    // complete task 1
    for(int i=1; i<worldSize; i++){
      //MPI_Isend(&one, 1, MPI_INT, i, 0 /* task one */, world, &rqsts[i-1]);
      MPI_Send(&one, 1, MPI_INT, i, 0 /* task one */, world);
    }
    printf("Task one done...\n");
    sleep(3);
    // complete task 3
    for(int i=1; i<worldSize; i++){
      //MPI_Isend(&one, 1, MPI_INT, i, 2 /* task three */, world,&rqsts[i-1+2]);
      MPI_Send(&one, 1, MPI_INT, i, 2 /* task three */, world);
    }
    printf("Task three done...\n");
    sleep(1);
    // complete task 2
    for(int i=1; i<worldSize; i++){
      MPI_Send(&one, 1, MPI_INT, i, 1 /* task two */, world);
    }
    printf("Task two done...\n");
    printf("Root has sent all tasks done...\n");
  } else {
    MPI_Request rqst[numTasks];
    int done[] = {0,0,0};
    MPI_Status status;
    for(int i=0; i<numTasks; i++){
        //MPI_Probe(0, MPI_ANY_TAG, world, &status);
        //printf("Status tag: %d, source: %d\n",
        //    status.MPI_TAG, status.MPI_SOURCE);
        MPI_Irecv(&tasksDone[i], 1, MPI_INT, 0, i, 
            world, &rqst[i]);
    }

    printf("Rank %d waiting for tasks to be done...\n", rank);
    while( !allDone ){
      sleep(1);
      allDone = 1;
      for(int i=0; i<numTasks; i++){
        if( !tasksDone[i] ) allDone = 0;
      }
      printf("Rank %d task status: %d %d %d\n", rank,
          tasksDone[0], tasksDone[1], tasksDone[2]);
      
      for(int i=0;i<numTasks;i++){
        MPI_Test(&rqst[i], &done[i], MPI_STATUS_IGNORE);
        //MPI_Wait(&rqst[i], MPI_STATUS_IGNORE);
      }
      printf("Rank %d request status: %d %d %d\n", rank,
          done[0], done[1], done[2]);
    }
    printf("Rank %d has all tasks done!\n", rank);
  }

  MPI_Finalize();
  return 0;
}
