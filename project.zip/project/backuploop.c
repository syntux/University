	//MPI_Irecv(&found[tag], 1, MPI_INT, MPI_ANY_SOURCE, tag, world, &req);
			/*
			for (int i = 0; i < 10; i++) {
				for (int j = 0; j < 10; j++) {
					for (int k = 0; k < 10; k++) {
						for (int v = 0; v < 10; v++) {
							for (int scount = 0; scount < 11; scount++) {	
								if (found[scount] == 1) {
									continue;
								}
								char *encrypt;
								if (k < 1 && j < 1 && i < 1) {
									//if (v == 9) printf("num: %d\n", strcmp(crypt(tmp, shadowList[scount].combine), shadowList[count].password));
									//if (v == 9) printf("%s tmp %s ANS: %s", encrypt, tmp, shadowList[scount].password);
									//if (v == 9) printf("tmp: %s enc %s her %s\n", shadowList[count].password, crypt(tmp, shadowList[scount].combine), tmp);
									//encrypt = crypt(tmp, shadowList[scount].combine);	
									sprintf(tmp, "%d%s", v, buf);
									encrypt = crypt(tmp, shadowList[scount].combine);
										//printf("true : user %s\n", shadowList[scount].username);	
										//printf("user: %s ENCRY: %s\n", shadowList[scount].password, encrypt);	
									if ((strcmp(encrypt, shadowList[scount].password)) == 0) {
										found[scount] = 1;
										fprintf(res, "Username: %s and password %s\n", shadowList[scount].username, tmp);
										for (int nodes = 0; nodes < worldSize; nodes++) {
											MPI_Send(&one, 1, MPI_INT, nodes, scount, world);
										}
										memset(r, ' ', 100);
										r[99] = '\n';
										sprintf(r, "Username: %s and password %s\n", shadowList[scount].username, tmp);
										int offset = (scount)*100*sizeof(char);

										MPI_File_write_at(
											fh,
											offset,
											r,
											100,
											MPI_CHAR,
											MPI_STATUS_IGNORE);
									}

									sprintf(tmp, "%s%d", buf, v);
									encrypt = crypt(tmp, shadowList[scount].combine);	
									if ((strcmp(encrypt, shadowList[scount].password)) == 0) {
										found[scount] = 1;
										fprintf(res, "Username: %s and password %s\n", shadowList[scount].username, tmp);
										for (int nodes = 0; nodes < worldSize; nodes++) {
											MPI_Send(&one, 1, MPI_INT, nodes, scount, world);
										}
										memset(r, ' ', 100);
										r[99] = '\n';
										sprintf(r, "Username: %s and password %s\n", shadowList[scount].username, tmp);
										int offset = (scount)*100*sizeof(char);

										MPI_File_write_at(
											fh,
											offset,
											r,
											100,
											MPI_CHAR,
											MPI_STATUS_IGNORE);
									}

									sprintf(tmp, "%d%d%s", k, v, buf);
									encrypt = crypt(tmp, shadowList[scount].combine);	
									if ((strcmp(encrypt, shadowList[scount].password)) == 0) {
										found[scount] = 1;
										fprintf(res, "Username: %s and password %s\n", shadowList[scount].username, tmp);
										for (int nodes = 0; nodes < worldSize; nodes++) {
											MPI_Send(&one, 1, MPI_INT, nodes, scount, world);
										}
										memset(r, ' ', 100);
										r[99] = '\n';
										sprintf(r, "Username: %s and password %s\n", shadowList[scount].username, tmp);
										int offset = (scount)*100*sizeof(char);

										MPI_File_write_at(
											fh,
											offset,
											r,
											100,
											MPI_CHAR,
											MPI_STATUS_IGNORE);
									}	

									sprintf(tmp, "%s%d%d", buf, k, v);
									encrypt = crypt(tmp, shadowList[scount].combine);	
									if ((strcmp(encrypt, shadowList[scount].password)) == 0) {
										found[scount] = 1;
										fprintf(res, "Username: %s and password %s\n", shadowList[scount].username, tmp);
										for (int nodes = 0; nodes < worldSize; nodes++) {
											MPI_Send(&one, 1, MPI_INT, nodes, scount, world);
										}
										memset(r, ' ', 100);
										r[99] = '\n';
										sprintf(r, "Username: %s and password %s\n", shadowList[scount].username, tmp);
										int offset = (scount)*100*sizeof(char);

										MPI_File_write_at(
											fh,
											offset,
											r,
											100,
											MPI_CHAR,
											MPI_STATUS_IGNORE);
									}


									sprintf(tmp, "%d%d%d%s", j, k, v, buf);
									encrypt = crypt(tmp, shadowList[scount].combine);	
									if ((strcmp(encrypt, shadowList[scount].password)) == 0) {
										found[scount] = 1;
										fprintf(res, "Username: %s and password %s\n", shadowList[scount].username, tmp);
										for (int nodes = 0; nodes < worldSize; nodes++) {
											MPI_Send(&one, 1, MPI_INT, nodes, scount, world);
										}
										memset(r, ' ', 100);
										r[99] = '\n';
										sprintf(r, "Username: %s and password %s\n", shadowList[scount].username, tmp);
										int offset = (scount)*100*sizeof(char);

										MPI_File_write_at(
											fh,
											offset,
											r,
											100,
											MPI_CHAR,
											MPI_STATUS_IGNORE);
									}

									sprintf(tmp, "%s%d%d%d", buf, j, k, v);
									encrypt = crypt(tmp, shadowList[scount].combine);	
									if ((strcmp(encrypt, shadowList[scount].password)) == 0) {
										found[scount] = 1;
										fprintf(res, "Username: %s and password %s\n", shadowList[scount].username, tmp);
										for (int nodes = 0; nodes < worldSize; nodes++) {
											MPI_Send(&one, 1, MPI_INT, nodes, scount, world);
										}
										memset(r, ' ', 100);
										r[99] = '\n';
										sprintf(r, "Username: %s and password %s\n", shadowList[scount].username, tmp);
										int offset = (scount)*100*sizeof(char);

										MPI_File_write_at(
											fh,
											offset,
											r,
											100,
											MPI_CHAR,
											MPI_STATUS_IGNORE);
									}

									sprintf(tmp, "%d%d%d%d%s", i, j, k, v, buf);
									encrypt = crypt(tmp, shadowList[scount].combine);	
									if ((strcmp(encrypt, shadowList[scount].password)) == 0) {
										found[scount] = 1;
										fprintf(res, "Username: %s and password %s\n", shadowList[scount].username, tmp);
										for (int nodes = 0; nodes < worldSize; nodes++) {
											MPI_Send(&one, 1, MPI_INT, nodes, scount, world);
										}
										memset(r, ' ', 100);
										r[99] = '\n';
										sprintf(r, "Username: %s and password %s\n", shadowList[scount].username, tmp);
										int offset = (scount)*100*sizeof(char);

										MPI_File_write_at(
											fh,
											offset,
											r,
											100,
											MPI_CHAR,
											MPI_STATUS_IGNORE);
									}

									sprintf(tmp, "%s%d%d%d%d", buf, i, j, k, v);
									encrypt = crypt(tmp, shadowList[scount].combine);	
									if ((strcmp(encrypt, shadowList[scount].password)) == 0) {
										found[scount] = 1;
										fprintf(res, "Username: %s and password %s\n", shadowList[scount].username, tmp);
										for (int nodes = 0; nodes < worldSize; nodes++) {
											MPI_Send(&one, 1, MPI_INT, nodes, scount, world);
										}
										memset(r, ' ', 100);
										r[99] = '\n';
										sprintf(r, "Username: %s and password %s\n", shadowList[scount].username, tmp);
										int offset = (scount)*100*sizeof(char);

										MPI_File_write_at(
											fh,
											offset,
											r,
											100,
											MPI_CHAR,
											MPI_STATUS_IGNORE);
									}
								}	
								if (k >= 1 && j < 1 && i < 1) {
									sprintf(tmp, "%d%d%s", k, v, buf);
									encrypt = crypt(tmp, shadowList[scount].combine);	
									if ((strcmp(encrypt, shadowList[scount].password)) == 0) {
										found[scount] = 1;
										fprintf(res, "Username: %s and password %s\n", shadowList[scount].username, tmp);
										for (int nodes = 0; nodes < worldSize; nodes++) {
											MPI_Send(&one, 1, MPI_INT, nodes, scount, world);
										}
										memset(r, ' ', 100);
										r[99] = '\n';
										sprintf(r, "Username: %s and password %s\n", shadowList[scount].username, tmp);
										int offset = (scount)*100*sizeof(char);

										MPI_File_write_at(
											fh,
											offset,
											r,
											100,
											MPI_CHAR,
											MPI_STATUS_IGNORE);
									}

									sprintf(tmp, "%s%d%d", buf, k, v);
									encrypt = crypt(tmp, shadowList[scount].combine);	
									if ((strcmp(encrypt, shadowList[scount].password)) == 0) {
										found[scount] = 1;
										fprintf(res, "Username: %s and password %s\n", shadowList[scount].username, tmp);
										for (int nodes = 0; nodes < worldSize; nodes++) {
											MPI_Send(&one, 1, MPI_INT, nodes, scount, world);
										}
										memset(r, ' ', 100);
										r[99] = '\n';
										sprintf(r, "Username: %s and password %s\n", shadowList[scount].username, tmp);
										int offset = (scount)*100*sizeof(char);

										MPI_File_write_at(
											fh,
											offset,
											r,
											100,
											MPI_CHAR,
											MPI_STATUS_IGNORE);
									}

									sprintf(tmp, "%d%d%d%s", j, k, v, buf);
									encrypt = crypt(tmp, shadowList[scount].combine);	
									if ((strcmp(encrypt, shadowList[scount].password)) == 0) {
										found[scount] = 1;
										fprintf(res, "Username: %s and password %s\n", shadowList[scount].username, tmp);
										for (int nodes = 0; nodes < worldSize; nodes++) {
											MPI_Send(&one, 1, MPI_INT, nodes, scount, world);
										}
										memset(r, ' ', 100);
										r[99] = '\n';
										sprintf(r, "Username: %s and password %s\n", shadowList[scount].username, tmp);
										int offset = (scount)*100*sizeof(char);

										MPI_File_write_at(
											fh,
											offset,
											r,
											100,
											MPI_CHAR,
											MPI_STATUS_IGNORE);
									}

									sprintf(tmp, "%s%d%d%d", buf, j, k, v);
									encrypt = crypt(tmp, shadowList[scount].combine);	
									if ((strcmp(encrypt, shadowList[scount].password)) == 0) {
										found[scount] = 1;
										fprintf(res, "Username: %s and password %s\n", shadowList[scount].username, tmp);
										for (int nodes = 0; nodes < worldSize; nodes++) {
											MPI_Send(&one, 1, MPI_INT, nodes, scount, world);
										}
										memset(r, ' ', 100);
										r[99] = '\n';
										sprintf(r, "Username: %s and password %s\n", shadowList[scount].username, tmp);
										int offset = (scount)*100*sizeof(char);

										MPI_File_write_at(
											fh,
											offset,
											r,
											100,
											MPI_CHAR,
											MPI_STATUS_IGNORE);
									}

									sprintf(tmp, "%d%d%d%d%s", i, j, k, v, buf);
									encrypt = crypt(tmp, shadowList[scount].combine);	
									if ((strcmp(encrypt, shadowList[scount].password)) == 0) {
										found[scount] = 1;
										fprintf(res, "Username: %s and password %s\n", shadowList[scount].username, tmp);
										for (int nodes = 0; nodes < worldSize; nodes++) {
											MPI_Send(&one, 1, MPI_INT, nodes, scount, world);
										}
										memset(r, ' ', 100);
										r[99] = '\n';
										sprintf(r, "Username: %s and password %s\n", shadowList[scount].username, tmp);
										int offset = (scount)*100*sizeof(char);

										MPI_File_write_at(
											fh,
											offset,
											r,
											100,
											MPI_CHAR,
											MPI_STATUS_IGNORE);
									}

									sprintf(tmp, "%s%d%d%d%d", buf, i, j, k, v);
									encrypt = crypt(tmp, shadowList[scount].combine);	
									if ((strcmp(encrypt, shadowList[scount].password)) == 0) {
										found[scount] = 1;
										fprintf(res, "Username: %s and password %s\n", shadowList[scount].username, tmp);
										for (int nodes = 0; nodes < worldSize; nodes++) {
											MPI_Send(&one, 1, MPI_INT, nodes, scount, world);
										}
										memset(r, ' ', 100);
										r[99] = '\n';
										sprintf(r, "Username: %s and password %s\n", shadowList[scount].username, tmp);
										int offset = (scount)*100*sizeof(char);

										MPI_File_write_at(
											fh,
											offset,
											r,
											100,
											MPI_CHAR,
											MPI_STATUS_IGNORE);
									}
								}	
								if (j >= 1 && i < 1) {
									sprintf(tmp, "%d%d%d%s", j, k, v, buf);
									encrypt = crypt(tmp, shadowList[scount].combine);	
									if ((strcmp(encrypt, shadowList[scount].password)) == 0) {
										found[scount] = 1;
										fprintf(res, "Username: %s and password %s\n", shadowList[scount].username, tmp);
										for (int nodes = 0; nodes < worldSize; nodes++) {
											MPI_Send(&one, 1, MPI_INT, nodes, scount, world);
										}
										memset(r, ' ', 100);
										r[99] = '\n';
										sprintf(r, "Username: %s and password %s\n", shadowList[scount].username, tmp);
										int offset = (scount)*100*sizeof(char);

										MPI_File_write_at(
											fh,
											offset,
											r,
											100,
											MPI_CHAR,
											MPI_STATUS_IGNORE);
									}

									sprintf(tmp, "%s%d%d%d", buf, j, k, v);
									encrypt = crypt(tmp, shadowList[scount].combine);	
									if ((strcmp(encrypt, shadowList[scount].password)) == 0) {
										found[scount] = 1;
										fprintf(res, "Username: %s and password %s\n", shadowList[scount].username, tmp);
										for (int nodes = 0; nodes < worldSize; nodes++) {
											MPI_Send(&one, 1, MPI_INT, nodes, scount, world);
										}
										memset(r, ' ', 100);
										r[99] = '\n';
										sprintf(r, "Username: %s and password %s\n", shadowList[scount].username, tmp);
										int offset = (scount)*100*sizeof(char);

										MPI_File_write_at(
											fh,
											offset,
											r,
											100,
											MPI_CHAR,
											MPI_STATUS_IGNORE);
									}

									sprintf(tmp, "%d%d%d%d%s", i, j, k, v, buf);
									encrypt = crypt(tmp, shadowList[scount].combine);	
									if ((strcmp(encrypt, shadowList[scount].password)) == 0) {
										found[scount] = 1;
										fprintf(res, "Username: %s and password %s\n", shadowList[scount].username, tmp);
										for (int nodes = 0; nodes < worldSize; nodes++) {
											MPI_Send(&one, 1, MPI_INT, nodes, scount, world);
										}
										memset(r, ' ', 100);
										r[99] = '\n';
										sprintf(r, "Username: %s and password %s\n", shadowList[scount].username, tmp);
										int offset = (scount)*100*sizeof(char);

										MPI_File_write_at(
											fh,
											offset,
											r,
											100,
											MPI_CHAR,
											MPI_STATUS_IGNORE);
									}
									sprintf(tmp, "%s%d%d%d%d", buf, i, j, k, v);
									encrypt = crypt(tmp, shadowList[scount].combine);	
									if ((strcmp(encrypt, shadowList[scount].password)) == 0) {
										found[scount] = 1;
										fprintf(res, "Username: %s and password %s\n", shadowList[scount].username, tmp);
										for (int nodes = 0; nodes < worldSize; nodes++) {
											MPI_Send(&one, 1, MPI_INT, nodes, scount, world);
										}
										memset(r, ' ', 100);
										r[99] = '\n';
										sprintf(r, "Username: %s and password %s\n", shadowList[scount].username, tmp);
										int offset = (scount)*100*sizeof(char);

										MPI_File_write_at(
											fh,
											offset,
											r,
											100,
											MPI_CHAR,
											MPI_STATUS_IGNORE);
									}
								}	
								if (i >= 1) {
									sprintf(tmp, "%d%d%d%d%s", i, j, k, v, buf);
									encrypt = crypt(tmp, shadowList[scount].combine);	
									if ((strcmp(encrypt, shadowList[scount].password)) == 0) {
										found[scount] = 1;
										fprintf(res, "Username: %s and password %s\n", shadowList[scount].username, tmp);
										for (int nodes = 0; nodes < worldSize; nodes++) {
											MPI_Send(&one, 1, MPI_INT, nodes, scount, world);
										}
										memset(r, ' ', 100);
										r[99] = '\n';
										sprintf(r, "Username: %s and password %s\n", shadowList[scount].username, tmp);
										int offset = (scount)*100*sizeof(char);

										MPI_File_write_at(
											fh,
											offset,
											r,
											100,
											MPI_CHAR,
											MPI_STATUS_IGNORE);
									}
									//printf("%s\n", tmp);
									sprintf(tmp,"%s%d%d%d%d", buf, i, j, k, v);
									encrypt = crypt(tmp, shadowList[scount].combine);	
									if ((strcmp(encrypt, shadowList[scount].password)) == 0) {
										found[scount] = 1;
										fprintf(res, "Username: %s and password %s\n", shadowList[scount].username, tmp);
										for (int nodes = 0; nodes < worldSize; nodes++) {
											MPI_Send(&one, 1, MPI_INT, nodes, scount, world);
										}
										memset(r, ' ', 100);
										r[99] = '\n';
										sprintf(r, "Username: %s and password %s\n", shadowList[scount].username, tmp);
										int offset = (scount)*100*sizeof(char);

										MPI_File_write_at(
											fh,
											offset,
											r,
											100,
											MPI_CHAR,
											MPI_STATUS_IGNORE);
									}
								}
							}
						}
					}
				}
			}
			*/
			//printf("rank %d and word %s\n", rank, buf);
	//	for {	
	//	}
		/*
	for (i = 0; i < 235888; i++) {
		//printf("%s\n", words[i]);
		free(words[i]);
	}
*/

	/*
	printf("Rank %d - ", rank);
	for (int i = 0; i < 11; i++) {
		printf("%d ", found[i]);
	}
	puts("");
	*/

