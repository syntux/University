#!/bin/bash

#SBATCH --job-name=passwords
#SBATCH --ntasks=60
#SBATCH --time=40:00:00
#SBATCH --output=out/%n.log

module load mpi/mpich-3.2-x86_64

mpiexec /mnt/linuxlab/home/bsmith41/Documents/cosc420/project/password
