#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<string.h>
#include<mpi.h>
#include "util.h"

/*
 * Generate some numbers and parallel-write to a file
 * 1. Without views
 * 2. (Maybe an exercise) do with views
 */

int main(int argc, char** argv){
  MPI_Init(NULL,NULL);

  MPI_Comm world = MPI_COMM_WORLD;
  int rank, worldSize;
  MPI_Comm_size(world, &worldSize);
  MPI_Comm_rank(world, &rank);
  MPI_File fh;

  const char* fname = "outfile.data";
  int N = 10; // every proc write N ints to the file
  int offset;
  char chars[N+1]; // local array for now, need to malloc for large N
  char* buf;
  
  srand(time(0)+rank);

  for(int i=0; i<N; i++) chars[i] = '0' + rand()%10;
  chars[N] = '\0'; // = 0
  printf("Rank %d string: %s\n", rank, chars);

  MPI_File_open(
      world,  // comm
      fname,  // filename
      MPI_MODE_CREATE | MPI_MODE_RDWR, // mode
      MPI_INFO_NULL, // info structure
      &fh );

  // where to start writing into the file
  // i.e. leave room for previous ranks to write theirs
  offset = N*rank*sizeof(char);

  /*
   * To view the file as a human, need to decode the ascii
   * The `hexdump` utility is made for this!
   *
   * e.g. for N=10 we do
   * NB: the 4 is because each int is 4 bytes!
   * So 10/4 says to hexdump "for i = 1 to 10 read next 4 bytes and do format"
   * Using %3d because we know each is at most two digits long, so 3 gives
   * us at lease one whitespace in the output
   *
   * Note that, without the formatting you see the data in it's natural
   * state, little-endian encoding!
   *
   * hexdump -v -e '10/4 "%3d"' -e '"\n"' outfile.data
   *
   */

  // EXERCISE: convert this code to use MPI file views
  // instead of manual calculation

  // do the window calculation manually
  MPI_File_write_at(fh,
      offset, // offset
      chars, // buf
      N, 
      MPI_CHAR,
      MPI_STATUS_IGNORE );

  MPI_File_close(&fh);

  MPI_Finalize();
  return 0;
}


















