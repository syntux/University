Chloe VanCory & Kalyn Howes
Lab 4 
11.7.21

File Structures [contaings make instructions]:
- version1.c: ( CAN BUT COMMENTED OUT Root Reads in from the binData.txt file and scatters data this is demonstrated in the timingVersion1 file) . Contains 3 hardcoded examples which output the eigenvalues
    [make]
- version2.c: DID NOT USE 

- timingVersion1.C - generates the binData.txt with if not created. Program writes rowNum,colNum, data - doubles.  Rereads the file and calculates the eigenvalue by reading it in via version1. 
                    - must take 3 additional command line parametrs. rows , cols , iteration number 
    [make timingVersion1] 
     
- timingVersion2.C - generates the binData.txt if not created. Program writes rowNum,colNum, data - doubles. Rereads the file by every proc starts at the offset and reads X amount of rows calculated. and calculates the eigenvalue by reading it in via version2 method
                    - must take 3 additional command line parametrs. rows , cols , iteration number 
    [make timingVersion2]

- sampleoutput.txt: Contains output from the version1.c program [make]

- matdims: binary files that contains, rowNumber , colNumber
- matdata: binary files that contains the Matrix Data


NOTE* Makefile doesnt actually run the program... so you have to do that now , happy birthday! 

Timing Version1 vs Version2

*  these iterate 10 times or until the difference in x's is less than epsilon *
___________________________________________________________________________

VERSION 1:

----- 2 NODES -----
10x10
MPI_Wtime measured: 0.00170 seconds
MPI_Wtime measured: 0.00007 seconds

100x100
MPI_Wtime measured: 0.00023 seconds
MPI_Wtime measured: 0.00019 seconds

1000x1000
MPI_Wtime measured: 0.02424 seconds
MPI_Wtime measured: 0.02116 seconds

10000x10000
MPI_Wtime measured: 2.27428 seconds
MPI_Wtime measured: 2.27429 seconds


----- 3 NODES -----
10x10
MPI_Wtime measured: 0.00015 seconds
MPI_Wtime measured: 0.00015 seconds
MPI_Wtime measured: 0.00014 seconds

100x100
MPI_Wtime measured: 0.00033 seconds
MPI_Wtime measured: 0.00033 seconds
MPI_Wtime measured: 0.00030 seconds

1000x1000
MPI_Wtime measured: 0.03105 seconds
MPI_Wtime measured: 0.02520 seconds
MPI_Wtime measured: 0.02900 seconds

10000x10000
MPI_Wtime measured: 2.12364 seconds
MPI_Wtime measured: 1.61345 seconds
MPI_Wtime measured: 1.61335 seconds

___________________________________________________________________________

VERSION 2:

----- 2 NODES -----
10x10
MPI_Wtime measured: 0.00007 seconds
MPI_Wtime measured: 0.00007 seconds

100x100
MPI_Wtime measured: 0.00037 seconds
MPI_Wtime measured: 0.00036 seconds


1000x1000
MPI_Wtime measured: 0.01860 seconds
MPI_Wtime measured: 0.01861 seconds


10000x10000
MPI_Wtime measured: 1.78597 seconds
MPI_Wtime measured: 1.78597 seconds


----- 3 NODES -----
10x10
MPI_Wtime measured: 0.00015 seconds
MPI_Wtime measured: 0.00015 seconds
MPI_Wtime measured: 0.00015 seconds

100x100
MPI_Wtime measured: 0.00037 seconds
MPI_Wtime measured: 0.00037 seconds
MPI_Wtime measured: 0.00037 seconds

1000x1000
MPI_Wtime measured: 0.01693 seconds
MPI_Wtime measured: 0.01693 seconds
MPI_Wtime measured: 0.01693 seconds


10000x10000
MPI_Wtime measured: 2.05554 seconds
MPI_Wtime measured: 2.05556 seconds
MPI_Wtime measured: 2.05560 seconds




__________________________________________________________________________________

Comparing Version1 & Version2:

Based from our timing on (at most) 10,000x10,000 matrices, running on 2 or 3 nodes, it seems Version1 is slightly faster than Version2. The timing for these are in Timing.txt

__________________________________________________________________________________

(a) One iteration of the Power Method includes an entire matrix multiplication process, plus some constant calculations and a vector division by a scalar. With this, the time-complexity will be approximately O(n^3), with n being the dimensions of a square matrix. Of course as the matrix size increases, so will the time taken for the Power Method.

(b) Adding more nodes does not perfectly divide the time taken but it does improve it. For example, running Version1 on 10000x10000 on 2 nodes took about 2.3 seconds while it only took 1.6 on 3 nodes.

(c) There are many real-life applications of eigenvalues, which is what the Power Method finds. Eigenvalues are used for finding limits for communication systems, designing bridges, and even stereo systems. Using distributed code such as ours could speed up these processes and allow for more efficient use in engineering and business.

(d) - Freeing memory
    - Creating an error check if an eigenvalue was unable to be found after a certain threshold and the e was not method





